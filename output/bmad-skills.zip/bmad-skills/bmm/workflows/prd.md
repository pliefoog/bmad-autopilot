---
description: 'PRD tri-modal workflow - Create, Validate, or Edit comprehensive PRDs'
---

IT IS CRITICAL THAT YOU FOLLOW THIS COMMAND: LOAD the FULL @_bmad/bmm/workflows/2-plan-workflows/prd/workflow.md, READ its entire contents and follow its directions exactly!
