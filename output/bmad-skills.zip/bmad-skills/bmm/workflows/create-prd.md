---
description: 'Creates a comprehensive PRD through collaborative step-by-step discovery between two product managers working as peers.'
---

IT IS CRITICAL THAT YOU FOLLOW THIS COMMAND: LOAD the FULL @_bmad/bmm/workflows/2-plan-workflows/prd/workflow.md, READ its entire contents and follow its directions exactly!
